#Maitrey Patel
#20ce090


#TUPLES
#a. Write a Python program to create a tuple with different data types.
tup = (3,'python',3.14)

#b. Write a Python program to create a tuple with numbers and print one item.
numtup = (0,1,2,3,4,5,6,7,8,9)
print(numtup[3])

#c. Write a Python program to add an item in a tuple.
tup1 = (0,1,2,3)
tup2 = (4,5)
tup = tup1+tup2
print(tup)

#d. Write a Python program to convert a tuple to a string.
pytup = ('P','Y','T','H','O','N')
string_out = ''.join(pytup)
print(string_out)

#e. Write a Python program to find the length of a tuple.
print("Length of previous tuple: ",len(pytup))